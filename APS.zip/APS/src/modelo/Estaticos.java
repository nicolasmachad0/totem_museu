package modelo;

public class Estaticos
{
    public static String MENSAGEM; // atributo estático do tipo String
}
