package apresentacao;

import apresentacao.frmTeclado; //importando o frmTeclado da pasta apresentacao
import apresentacao.frmNumerico; //importando o frmNumerico da pasta apresentacao
import apresentacao.frmExposicao; //importando o frmExposicao da pasta apresentacao
import javax.swing.JOptionPane; //importando o JOptionPane de uma biblioteca do Java para exibir as mensagem do Estaticos
import modelo.Controle; //importando o Controle da pasta modelo
import modelo.Estaticos; //importando o Estaticos da pasta modelo

public class frmCadastro extends javax.swing.JDialog {

    public frmCadastro(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNome = new javax.swing.JLabel();
        txfNome = new javax.swing.JTextField();
        btnAbrirTeclado = new javax.swing.JButton();
        lblCPF = new javax.swing.JLabel();
        txfCPF = new javax.swing.JTextField();
        btnAbrirNumerico = new javax.swing.JButton();
        btnProsseguir = new javax.swing.JButton();
        lblAPS = new javax.swing.JLabel();
        lblParticipantes = new javax.swing.JLabel();
        lblTitulo = new javax.swing.JLabel();
        lblBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Cadastro");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblNome.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        lblNome.setForeground(new java.awt.Color(255, 255, 255));
        lblNome.setText("DIGITE SEU NOME:");
        getContentPane().add(lblNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 137, -1, -1));

        txfNome.setEditable(false);
        txfNome.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        txfNome.setText("  ");
        txfNome.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 3));
        txfNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txfNomeActionPerformed(evt);
            }
        });
        getContentPane().add(txfNome, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 182, 782, 35));

        btnAbrirTeclado.setText("escrever");
        btnAbrirTeclado.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        btnAbrirTeclado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirTecladoActionPerformed(evt);
            }
        });
        getContentPane().add(btnAbrirTeclado, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 223, 58, 35));

        lblCPF.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        lblCPF.setForeground(new java.awt.Color(255, 255, 255));
        lblCPF.setText("DIGITE SEU CPF:");
        getContentPane().add(lblCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 276, -1, -1));

        txfCPF.setEditable(false);
        txfCPF.setFont(new java.awt.Font("Dubai Medium", 1, 14)); // NOI18N
        txfCPF.setText("  ");
        txfCPF.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 51, 51), 3));
        txfCPF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txfCPFActionPerformed(evt);
            }
        });
        getContentPane().add(txfCPF, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 321, 782, 35));

        btnAbrirNumerico.setText("escrever");
        btnAbrirNumerico.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 102, 102)));
        btnAbrirNumerico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbrirNumericoActionPerformed(evt);
            }
        });
        getContentPane().add(btnAbrirNumerico, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 362, 58, 35));

        btnProsseguir.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        btnProsseguir.setText("PROSSEGUIR");
        btnProsseguir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProsseguirActionPerformed(evt);
            }
        });
        getContentPane().add(btnProsseguir, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 415, 350, 100));

        lblAPS.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblAPS.setForeground(new java.awt.Color(255, 255, 255));
        lblAPS.setText("Ciência da Computação - APS 2024");
        getContentPane().add(lblAPS, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 550, -1, -1));

        lblParticipantes.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblParticipantes.setForeground(new java.awt.Color(255, 255, 255));
        lblParticipantes.setText("Cassiano Melo - Gabriel dos Santos - Nicholas Brites - Nicolas Machado");
        getContentPane().add(lblParticipantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 575, -1, -1));

        lblTitulo.setBackground(new java.awt.Color(255, 124, 124));
        lblTitulo.setFont(new java.awt.Font("Bookman Old Style", 1, 48)); // NOI18N
        lblTitulo.setForeground(new java.awt.Color(255, 255, 255));
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Dados Cadastrais");
        getContentPane().add(lblTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 44, 800, 60));

        lblBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/cadastro-background.png"))); // NOI18N
        getContentPane().add(lblBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 600));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txfNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txfNomeActionPerformed
    }//GEN-LAST:event_txfNomeActionPerformed

    private void btnAbrirTecladoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirTecladoActionPerformed
        //ao clicar no botão abrirá o teclado virtual instanciando um objeto de frmTeclado
        frmTeclado frmT = new frmTeclado(null, true);
        frmT.setVisible(true);
        txfNome.setText(frmT.texto); // o texto que for escrito no teclado virtual será assumido pelo 'text field'
    }//GEN-LAST:event_btnAbrirTecladoActionPerformed

    private void txfCPFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txfCPFActionPerformed
    }//GEN-LAST:event_txfCPFActionPerformed

    private void btnAbrirNumericoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbrirNumericoActionPerformed
        //ao clicar no botão abrirá o teclado virtual instanciando um objeto de frmNumerico
        frmNumerico frmN = new frmNumerico(null, true);
        frmN.setVisible(true);
        txfCPF.setText(frmN.texto.substring(0, 3) + "." + frmN.texto.substring(3, 6) + "." + frmN.texto.substring(6, 9) + "-" + frmN.texto.substring(9));
        // os números que forem escritos no teclado numérico virtual será assumido pelo 'text field', e já formatado com "." e "-"
        // usando o comando substring, ele pegará a posição dos caracteres digitados e colocará então um "." após 3 números, depois após 6 números, e um "-" após o 9º 
    }//GEN-LAST:event_btnAbrirNumericoActionPerformed

    private void btnProsseguirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProsseguirActionPerformed
        // Instanciando um objeto da classe Controle, para que ele passe por uma validação e o programa entenda se é possível mesmo prosseguir
        Controle controle = new Controle(txfCPF.getText(), txfNome.getText());
        if(Estaticos.MENSAGEM.equals(""))
        {
            //se a mensagem do Estaticos estiver vazia é por que não deu erro, então pode fechar o frmCadastro e seguir, gerando um objeto de frmExposicao e tornando visível
            dispose();
            frmExposicao frmE = new frmExposicao(null, true);
            frmE.lblMensagem.setText("Como é bom ter você por aqui, " + txfNome.getText() + "!"); //inserindo uma mensagem personalizada de boas vindas na label do próximo formulário
            frmE.setVisible(true);

        }
        else
        {
            // se a mensagem do Estaticos não for vazia, então é pq deu erro, então mostrar uma mensagem de erros exibindo MENSAGEM e travando na mesma tela do frmCadastro
            JOptionPane.showMessageDialog(null, Estaticos.MENSAGEM);
        }
    }//GEN-LAST:event_btnProsseguirActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                frmCadastro dialog = new frmCadastro(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbrirNumerico;
    private javax.swing.JButton btnAbrirTeclado;
    private javax.swing.JButton btnProsseguir;
    private javax.swing.JLabel lblAPS;
    private javax.swing.JLabel lblBackground;
    private javax.swing.JLabel lblCPF;
    private javax.swing.JLabel lblNome;
    private javax.swing.JLabel lblParticipantes;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txfCPF;
    private javax.swing.JTextField txfNome;
    // End of variables declaration//GEN-END:variables

    private void setEditable(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String geTexto() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
