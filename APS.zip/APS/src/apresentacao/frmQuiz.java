package apresentacao;

import apresentacao.frmAvaliacao;  // importando o formulário frmAvaliacao

public class frmQuiz extends javax.swing.JDialog {

        public frmQuiz(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btgPergunta1 = new javax.swing.ButtonGroup();
        btgPergunta2 = new javax.swing.ButtonGroup();
        btgPergunta3 = new javax.swing.ButtonGroup();
        btgPergunta4 = new javax.swing.ButtonGroup();
        btgPergunta5 = new javax.swing.ButtonGroup();
        scrollPainel = new javax.swing.JScrollPane();
        painel = new javax.swing.JPanel();
        lblPergunta1 = new javax.swing.JLabel();
        lblQuestao1 = new javax.swing.JLabel();
        rdbResposta1A = new javax.swing.JRadioButton();
        rdbResposta1B = new javax.swing.JRadioButton();
        rdbResposta1C = new javax.swing.JRadioButton();
        rdbResposta1D = new javax.swing.JRadioButton();
        rdbResposta1E = new javax.swing.JRadioButton();
        rdbResposta2A = new javax.swing.JRadioButton();
        rdbResposta2B = new javax.swing.JRadioButton();
        rdbResposta2C = new javax.swing.JRadioButton();
        rdbResposta2D = new javax.swing.JRadioButton();
        rdbResposta2E = new javax.swing.JRadioButton();
        lblQuestao2 = new javax.swing.JLabel();
        lblPergunta2 = new javax.swing.JLabel();
        rdbResposta3E = new javax.swing.JRadioButton();
        lblPergunta3 = new javax.swing.JLabel();
        lblQuestao3 = new javax.swing.JLabel();
        rdbResposta3A = new javax.swing.JRadioButton();
        rdbResposta3B = new javax.swing.JRadioButton();
        rdbResposta3C = new javax.swing.JRadioButton();
        rdbResposta3D = new javax.swing.JRadioButton();
        lblPergunta4 = new javax.swing.JLabel();
        lblQuestao4 = new javax.swing.JLabel();
        rdbResposta4A = new javax.swing.JRadioButton();
        rdbResposta4B = new javax.swing.JRadioButton();
        rdbResposta4C = new javax.swing.JRadioButton();
        rdbResposta4D = new javax.swing.JRadioButton();
        rdbResposta4E = new javax.swing.JRadioButton();
        lblPergunta5 = new javax.swing.JLabel();
        lblQuestao5 = new javax.swing.JLabel();
        rdbResposta5A = new javax.swing.JRadioButton();
        rdbResposta5B = new javax.swing.JRadioButton();
        rdbResposta5C = new javax.swing.JRadioButton();
        rdbResposta5D = new javax.swing.JRadioButton();
        rdbResposta5E = new javax.swing.JRadioButton();
        btnResponder = new javax.swing.JButton();
        lblBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quiz");
        setMaximumSize(new java.awt.Dimension(839, 684));
        setMinimumSize(new java.awt.Dimension(839, 684));

        scrollPainel.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPainel.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPainel.setMaximumSize(new java.awt.Dimension(839, 684));
        scrollPainel.setMinimumSize(new java.awt.Dimension(839, 684));
        scrollPainel.setPreferredSize(new java.awt.Dimension(839, 684));

        painel.setName(""); // NOI18N
        painel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblPergunta1.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        lblPergunta1.setForeground(new java.awt.Color(255, 255, 255));
        lblPergunta1.setText("PERGUNTA 1:");
        painel.add(lblPergunta1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, -1, -1));

        lblQuestao1.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblQuestao1.setForeground(new java.awt.Color(255, 255, 255));
        lblQuestao1.setText(" Dentre todos os rovers citados nessa apresentação, qual deles é o menor?");
        painel.add(lblQuestao1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, -1, -1));

        rdbResposta1A.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta1.add(rdbResposta1A);
        rdbResposta1A.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta1A.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta1A.setSelected(true);
        rdbResposta1A.setText("Curiosity");
        rdbResposta1A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta1AActionPerformed(evt);
            }
        });
        painel.add(rdbResposta1A, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 50, -1, -1));

        rdbResposta1B.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta1.add(rdbResposta1B);
        rdbResposta1B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta1B.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta1B.setText("Opportunity");
        rdbResposta1B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta1BActionPerformed(evt);
            }
        });
        painel.add(rdbResposta1B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 80, -1, -1));

        rdbResposta1C.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta1.add(rdbResposta1C);
        rdbResposta1C.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta1C.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta1C.setText("Soujoner");
        rdbResposta1C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta1CActionPerformed(evt);
            }
        });
        painel.add(rdbResposta1C, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 110, -1, -1));

        rdbResposta1D.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta1.add(rdbResposta1D);
        rdbResposta1D.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta1D.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta1D.setText("Spirit");
        rdbResposta1D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta1DActionPerformed(evt);
            }
        });
        painel.add(rdbResposta1D, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, -1, -1));

        rdbResposta1E.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta1.add(rdbResposta1E);
        rdbResposta1E.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta1E.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta1E.setText("Perseverance");
        rdbResposta1E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta1EActionPerformed(evt);
            }
        });
        painel.add(rdbResposta1E, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, -1, -1));

        rdbResposta2A.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta2.add(rdbResposta2A);
        rdbResposta2A.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta2A.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta2A.setSelected(true);
        rdbResposta2A.setText("A existência de metais");
        rdbResposta2A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta2AActionPerformed(evt);
            }
        });
        painel.add(rdbResposta2A, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, -1, -1));

        rdbResposta2B.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta2.add(rdbResposta2B);
        rdbResposta2B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta2B.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta2B.setText("Que marte aparenta não ser somente um deserto seco");
        rdbResposta2B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta2BActionPerformed(evt);
            }
        });
        painel.add(rdbResposta2B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        rdbResposta2C.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta2.add(rdbResposta2C);
        rdbResposta2C.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta2C.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta2C.setText("A possibilidade de furar rochas marcianas");
        rdbResposta2C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta2CActionPerformed(evt);
            }
        });
        painel.add(rdbResposta2C, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, -1, -1));

        rdbResposta2D.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta2.add(rdbResposta2D);
        rdbResposta2D.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta2D.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta2D.setText("Moléculas orgânicas em uma cratera");
        rdbResposta2D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta2DActionPerformed(evt);
            }
        });
        painel.add(rdbResposta2D, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 350, -1, -1));

        rdbResposta2E.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta2.add(rdbResposta2E);
        rdbResposta2E.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta2E.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta2E.setText("Espécies de animais vivos em Marte");
        rdbResposta2E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta2EActionPerformed(evt);
            }
        });
        painel.add(rdbResposta2E, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 380, -1, -1));

        lblQuestao2.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblQuestao2.setForeground(new java.awt.Color(255, 255, 255));
        lblQuestao2.setText("Qual foi a grande descoberta do Perseverance?");
        painel.add(lblQuestao2, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 230, -1, -1));

        lblPergunta2.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        lblPergunta2.setForeground(new java.awt.Color(255, 255, 255));
        lblPergunta2.setText("PERGUNTA 2:");
        painel.add(lblPergunta2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 210, -1, -1));

        rdbResposta3E.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta3.add(rdbResposta3E);
        rdbResposta3E.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta3E.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta3E.setText("Rovers gêmeos");
        rdbResposta3E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta3EActionPerformed(evt);
            }
        });
        painel.add(rdbResposta3E, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 590, -1, -1));

        lblPergunta3.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        lblPergunta3.setForeground(new java.awt.Color(255, 255, 255));
        lblPergunta3.setText("PERGUNTA 3:");
        painel.add(lblPergunta3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 420, -1, -1));

        lblQuestao3.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblQuestao3.setForeground(new java.awt.Color(255, 255, 255));
        lblQuestao3.setText("Como era conhecida os rovers Spirit e Opportunity?");
        painel.add(lblQuestao3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 450, -1, -1));

        rdbResposta3A.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta3.add(rdbResposta3A);
        rdbResposta3A.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta3A.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta3A.setSelected(true);
        rdbResposta3A.setText("Gêmeos marcianos");
        rdbResposta3A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta3AActionPerformed(evt);
            }
        });
        painel.add(rdbResposta3A, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 470, -1, -1));

        rdbResposta3B.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta3.add(rdbResposta3B);
        rdbResposta3B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta3B.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta3B.setText("Dois rovers");
        rdbResposta3B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta3BActionPerformed(evt);
            }
        });
        painel.add(rdbResposta3B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 500, -1, -1));

        rdbResposta3C.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta3.add(rdbResposta3C);
        rdbResposta3C.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta3C.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta3C.setText("Irmãos rovers");
        rdbResposta3C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta3CActionPerformed(evt);
            }
        });
        painel.add(rdbResposta3C, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 530, -1, -1));

        rdbResposta3D.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta3.add(rdbResposta3D);
        rdbResposta3D.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta3D.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta3D.setText("Dupla de marte");
        rdbResposta3D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta3DActionPerformed(evt);
            }
        });
        painel.add(rdbResposta3D, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 560, -1, -1));

        lblPergunta4.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        lblPergunta4.setForeground(new java.awt.Color(255, 255, 255));
        lblPergunta4.setText("PERGUNTA 4:");
        painel.add(lblPergunta4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 630, -1, -1));

        lblQuestao4.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblQuestao4.setForeground(new java.awt.Color(255, 255, 255));
        lblQuestao4.setText("O que era fundamental para o funcionamento de rovers antigos como Soujoner, Spirit e Opportunity?");
        painel.add(lblQuestao4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 660, -1, -1));

        rdbResposta4A.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta4.add(rdbResposta4A);
        rdbResposta4A.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta4A.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta4A.setSelected(true);
        rdbResposta4A.setText("Painéis solares em sua carcaça");
        rdbResposta4A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta4AActionPerformed(evt);
            }
        });
        painel.add(rdbResposta4A, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 680, -1, -1));

        rdbResposta4B.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta4.add(rdbResposta4B);
        rdbResposta4B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta4B.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta4B.setText("Carregadores via cabo, na base de suas naves");
        rdbResposta4B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta4BActionPerformed(evt);
            }
        });
        painel.add(rdbResposta4B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 710, -1, -1));

        rdbResposta4C.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta4.add(rdbResposta4C);
        rdbResposta4C.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta4C.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta4C.setText("Carregadores via sensor, na base de suas naves");
        rdbResposta4C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta4CActionPerformed(evt);
            }
        });
        painel.add(rdbResposta4C, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 740, -1, -1));

        rdbResposta4D.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta4.add(rdbResposta4D);
        rdbResposta4D.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta4D.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta4D.setText("Energia eólica, devido aos fortes ventos em marte");
        rdbResposta4D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta4DActionPerformed(evt);
            }
        });
        painel.add(rdbResposta4D, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 770, -1, -1));

        rdbResposta4E.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta4.add(rdbResposta4E);
        rdbResposta4E.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta4E.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta4E.setText("Pilhas hiper potentes em parceria com uma empresa americana");
        rdbResposta4E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta4EActionPerformed(evt);
            }
        });
        painel.add(rdbResposta4E, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 800, -1, -1));

        lblPergunta5.setFont(new java.awt.Font("Arial Black", 1, 16)); // NOI18N
        lblPergunta5.setForeground(new java.awt.Color(255, 255, 255));
        lblPergunta5.setText("PERGUNTA 5:");
        painel.add(lblPergunta5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 830, -1, -1));

        lblQuestao5.setFont(new java.awt.Font("Segoe UI", 0, 16)); // NOI18N
        lblQuestao5.setForeground(new java.awt.Color(255, 255, 255));
        lblQuestao5.setText("Em que ano pousou o primeiro rover no planeta vermelho?");
        painel.add(lblQuestao5, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 850, -1, -1));

        rdbResposta5A.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta5.add(rdbResposta5A);
        rdbResposta5A.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta5A.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta5A.setSelected(true);
        rdbResposta5A.setText("2004");
        rdbResposta5A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta5AActionPerformed(evt);
            }
        });
        painel.add(rdbResposta5A, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 870, -1, -1));

        rdbResposta5B.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta5.add(rdbResposta5B);
        rdbResposta5B.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta5B.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta5B.setText("1997");
        rdbResposta5B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta5BActionPerformed(evt);
            }
        });
        painel.add(rdbResposta5B, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 900, -1, -1));

        rdbResposta5C.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta5.add(rdbResposta5C);
        rdbResposta5C.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta5C.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta5C.setText("1972");
        rdbResposta5C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta5CActionPerformed(evt);
            }
        });
        painel.add(rdbResposta5C, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 930, -1, -1));

        rdbResposta5D.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta5.add(rdbResposta5D);
        rdbResposta5D.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta5D.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta5D.setText("Será lançado em 2028");
        rdbResposta5D.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta5DActionPerformed(evt);
            }
        });
        painel.add(rdbResposta5D, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 960, -1, -1));

        rdbResposta5E.setBackground(new java.awt.Color(51, 0, 0));
        btgPergunta5.add(rdbResposta5E);
        rdbResposta5E.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        rdbResposta5E.setForeground(new java.awt.Color(255, 255, 255));
        rdbResposta5E.setText("2021");
        rdbResposta5E.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbResposta5EActionPerformed(evt);
            }
        });
        painel.add(rdbResposta5E, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 990, -1, -1));

        btnResponder.setBackground(new java.awt.Color(243, 243, 243));
        btnResponder.setFont(new java.awt.Font("Bookman Old Style", 1, 48)); // NOI18N
        btnResponder.setForeground(new java.awt.Color(107, 0, 0));
        btnResponder.setText("RESPONDER");
        btnResponder.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(61, 23, 23), 5));
        btnResponder.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResponderActionPerformed(evt);
            }
        });
        painel.add(btnResponder, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 1030, 400, 101));

        lblBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/quiz-background.png"))); // NOI18N
        painel.add(lblBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 1160));

        scrollPainel.setViewportView(painel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollPainel, javax.swing.GroupLayout.DEFAULT_SIZE, 862, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(scrollPainel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    // uma série de códigos gerados acidentalmente, eles estão vazios, e o grupo pede desculpas
    private void rdbResposta1AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta1AActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta1AActionPerformed
    private void rdbResposta1BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta1BActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta1BActionPerformed
    private void rdbResposta1CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta1CActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta1CActionPerformed
    private void rdbResposta1DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta1DActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta1DActionPerformed
    private void rdbResposta1EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta1EActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta1EActionPerformed
    private void rdbResposta2AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta2AActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta2AActionPerformed
    private void rdbResposta2BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta2BActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta2BActionPerformed
    private void rdbResposta2CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta2CActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta2CActionPerformed
    private void rdbResposta2DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta2DActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta2DActionPerformed
    private void rdbResposta2EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta2EActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta2EActionPerformed
    private void rdbResposta3EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta3EActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta3EActionPerformed
    private void rdbResposta3AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta3AActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta3AActionPerformed
    private void rdbResposta3BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta3BActionPerformed
    }//GEN-LAST:event_rdbResposta3BActionPerformed
    private void rdbResposta3CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta3CActionPerformed
    }//GEN-LAST:event_rdbResposta3CActionPerformed
    private void rdbResposta3DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta3DActionPerformed
    }//GEN-LAST:event_rdbResposta3DActionPerformed
    private void rdbResposta4AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta4AActionPerformed
    }//GEN-LAST:event_rdbResposta4AActionPerformed
    private void rdbResposta4BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta4BActionPerformed
    }//GEN-LAST:event_rdbResposta4BActionPerformed
    private void rdbResposta4CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta4CActionPerformed
    }//GEN-LAST:event_rdbResposta4CActionPerformed
    private void rdbResposta4DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta4DActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta4DActionPerformed
    private void rdbResposta4EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta4EActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta4EActionPerformed
    private void rdbResposta5AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta5AActionPerformed
    }//GEN-LAST:event_rdbResposta5AActionPerformed
    private void rdbResposta5BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta5BActionPerformed
    }//GEN-LAST:event_rdbResposta5BActionPerformed
    private void rdbResposta5CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta5CActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbResposta5CActionPerformed
    private void rdbResposta5DActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta5DActionPerformed
    }//GEN-LAST:event_rdbResposta5DActionPerformed
    private void rdbResposta5EActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbResposta5EActionPerformed
    }//GEN-LAST:event_rdbResposta5EActionPerformed

    private void btnResponderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResponderActionPerformed
        int acertos = 0; // criando um atributo interno do tipo int e valor zero
        
        // vai conferir se cada um dos radio button's estão selecionados, e se sim, somar +1 no valor de acertos
        if(rdbResposta1C.isSelected()){acertos = acertos + 1;}
        if(rdbResposta2D.isSelected()){acertos = acertos + 1;}
        if(rdbResposta3E.isSelected()){acertos = acertos + 1;}
        if(rdbResposta4A.isSelected()){acertos = acertos + 1;}
        if(rdbResposta5B.isSelected()){acertos = acertos + 1;}
        
        // fecha a tela do Quiz e cria um objeto para tornar visível a tela da classe frmAvaliacao
        dispose();
        frmAvaliacao frmA = new frmAvaliacao(null, true);
        frmA.lblNota.setText(String.valueOf(acertos)); //envia o valor da quantidade de acertos para o objeto do frmAvaliacao
        frmA.setVisible(true);
    }//GEN-LAST:event_btnResponderActionPerformed

    public static void main(String args[]) {
}

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btgPergunta1;
    private javax.swing.ButtonGroup btgPergunta2;
    private javax.swing.ButtonGroup btgPergunta3;
    private javax.swing.ButtonGroup btgPergunta4;
    private javax.swing.ButtonGroup btgPergunta5;
    private javax.swing.JButton btnResponder;
    private javax.swing.JLabel lblBackground;
    private javax.swing.JLabel lblPergunta1;
    private javax.swing.JLabel lblPergunta2;
    private javax.swing.JLabel lblPergunta3;
    private javax.swing.JLabel lblPergunta4;
    private javax.swing.JLabel lblPergunta5;
    private javax.swing.JLabel lblQuestao1;
    private javax.swing.JLabel lblQuestao2;
    private javax.swing.JLabel lblQuestao3;
    private javax.swing.JLabel lblQuestao4;
    private javax.swing.JLabel lblQuestao5;
    private javax.swing.JPanel painel;
    private javax.swing.JRadioButton rdbResposta1A;
    private javax.swing.JRadioButton rdbResposta1B;
    private javax.swing.JRadioButton rdbResposta1C;
    private javax.swing.JRadioButton rdbResposta1D;
    private javax.swing.JRadioButton rdbResposta1E;
    private javax.swing.JRadioButton rdbResposta2A;
    private javax.swing.JRadioButton rdbResposta2B;
    private javax.swing.JRadioButton rdbResposta2C;
    private javax.swing.JRadioButton rdbResposta2D;
    private javax.swing.JRadioButton rdbResposta2E;
    private javax.swing.JRadioButton rdbResposta3A;
    private javax.swing.JRadioButton rdbResposta3B;
    private javax.swing.JRadioButton rdbResposta3C;
    private javax.swing.JRadioButton rdbResposta3D;
    private javax.swing.JRadioButton rdbResposta3E;
    private javax.swing.JRadioButton rdbResposta4A;
    private javax.swing.JRadioButton rdbResposta4B;
    private javax.swing.JRadioButton rdbResposta4C;
    private javax.swing.JRadioButton rdbResposta4D;
    private javax.swing.JRadioButton rdbResposta4E;
    private javax.swing.JRadioButton rdbResposta5A;
    private javax.swing.JRadioButton rdbResposta5B;
    private javax.swing.JRadioButton rdbResposta5C;
    private javax.swing.JRadioButton rdbResposta5D;
    private javax.swing.JRadioButton rdbResposta5E;
    private javax.swing.JScrollPane scrollPainel;
    // End of variables declaration//GEN-END:variables
}
