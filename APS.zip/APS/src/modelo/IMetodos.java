package modelo;

public interface IMetodos //declaração de uma interface
{
    public void Executar(); // método que tomará diversas formas ao longo do código
}
