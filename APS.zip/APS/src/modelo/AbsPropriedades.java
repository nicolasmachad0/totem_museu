package modelo;


//tornando a classe AbsPropriedades uma classe abstrata para que ela possa herdar seus atributos e construtores para outras classes
//implementando métodos declarados na interface IMetodos
public abstract class AbsPropriedades implements IMetodos
{
    //criando atributos públicos e do tipo String
    public String cpf; 
    public String nome;
    
    //criando um construtor com os parâmetros cpf e nome
    public AbsPropriedades(String cpf, String nome) {
        this.cpf = cpf;
        this.nome = nome;
        this.Executar();
    }
}
