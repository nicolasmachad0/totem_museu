package modelo;

public class Validacao extends AbsPropriedades // herdando atributos e construtores da classe 
{

    // construtor herdado da classe AbsPropriedades
    public Validacao(String cpf, String nome) {
        super(cpf, nome);
    }

    // método que foi implementado da classe IMetodos na classe AbsPropriedades
    @Override
    public void Executar()
    {
        
        // lógica para conferir se os dados inseridos em nome e cpf são válidos
        if(nome.equals(""))
        {
            Estaticos.MENSAGEM = "Digite seu nome, por favor!";
            // caso o campo nome chegue vazio, o MENSAGEM da classe Estaticos deve assumir um texto de erro
        }
        else
        {
            if(cpf.length() != 14) // se o campo nome não estiver vazio, então conferir se o campo cpf tem 14 caracteres(contando com "." e "-")
            {
                Estaticos.MENSAGEM = "o CPF está inválido, é preciso ter 11 dígitos.";
               // e se for diferente de 14 caracteres, o MENSAGEM da classe Estaticos assumir outra mensagem de erro
            }
        }
    }
    
}
