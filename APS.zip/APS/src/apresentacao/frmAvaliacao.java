package apresentacao;

import apresentacao.frmResumo;  // importando o formulário frmResumo

public class frmAvaliacao extends javax.swing.JDialog {

    public frmAvaliacao(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblFrase1 = new javax.swing.JLabel();
        lblAlienNeutra = new javax.swing.JLabel();
        lblAlienOtima = new javax.swing.JLabel();
        lblAlienRuim = new javax.swing.JLabel();
        lblFrase2 = new javax.swing.JLabel();
        btnOtima = new javax.swing.JButton();
        btnRuim = new javax.swing.JButton();
        btnNeutra = new javax.swing.JButton();
        lblAPS = new javax.swing.JLabel();
        lblParticipantes = new javax.swing.JLabel();
        lblBackground = new javax.swing.JLabel();
        lblNota = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Avaliação");
        setMaximumSize(new java.awt.Dimension(839, 684));
        setMinimumSize(new java.awt.Dimension(839, 684));
        setPreferredSize(new java.awt.Dimension(839, 684));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblFrase1.setFont(new java.awt.Font("Segoe UI Semibold", 0, 18)); // NOI18N
        lblFrase1.setForeground(new java.awt.Color(255, 255, 255));
        lblFrase1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrase1.setText("Antes de ver sua pontuação no quiz");
        getContentPane().add(lblFrase1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-2, 130, 840, -1));

        lblAlienNeutra.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/alien-neutra.png"))); // NOI18N
        getContentPane().add(lblAlienNeutra, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 290, -1, -1));

        lblAlienOtima.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/alien-otima.png"))); // NOI18N
        getContentPane().add(lblAlienOtima, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 290, -1, -1));

        lblAlienRuim.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/alien-ruim.png"))); // NOI18N
        getContentPane().add(lblAlienRuim, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, -1, -1));

        lblFrase2.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        lblFrase2.setForeground(new java.awt.Color(255, 255, 255));
        lblFrase2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrase2.setText("AVALIE SUA EXPERIÊNCIA PARA FINALIZAR!");
        getContentPane().add(lblFrase2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 820, -1));

        btnOtima.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnOtima.setText("ÓTIMA");
        btnOtima.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 0, 0), 5));
        btnOtima.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOtimaActionPerformed(evt);
            }
        });
        getContentPane().add(btnOtima, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 490, 200, 70));

        btnRuim.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnRuim.setText("RUIM");
        btnRuim.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 0, 0), 5));
        btnRuim.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRuimActionPerformed(evt);
            }
        });
        getContentPane().add(btnRuim, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 490, 200, 70));

        btnNeutra.setFont(new java.awt.Font("Segoe UI Black", 0, 18)); // NOI18N
        btnNeutra.setText("NEUTRA");
        btnNeutra.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 0, 0), 5));
        btnNeutra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNeutraActionPerformed(evt);
            }
        });
        getContentPane().add(btnNeutra, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 490, 200, 70));

        lblAPS.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblAPS.setForeground(new java.awt.Color(255, 255, 255));
        lblAPS.setText("Ciência da Computação - APS 2024");
        getContentPane().add(lblAPS, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 590, -1, -1));

        lblParticipantes.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblParticipantes.setForeground(new java.awt.Color(255, 255, 255));
        lblParticipantes.setText("Cassiano Melo - Gabriel dos Santos - Nicholas Brites - Nicolas Machado");
        getContentPane().add(lblParticipantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 610, -1, -1));

        lblBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/avaliacao-background.png"))); // NOI18N
        getContentPane().add(lblBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 690));

        lblNota.setText("NOTA");
        getContentPane().add(lblNota, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    // todos os 3 botões fecham a tela do frmAvaliacao e então geram a tela do frmResumo através de uma instância do objeto da mesma
    // após o objeto ser feito, os botões fazem com que a label que mostra o número de acertos no quiz exiba o resutado, que foi recebido da frmQuiz
    // e também, exibe uma mensagem de agradecimento pelo feedback do usuário, com uma mensagem personalizada pra cada tipo de avaliação(ruim, neutra ou ótima)
    private void btnOtimaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOtimaActionPerformed
        dispose();
        frmResumo frmR = new frmResumo(null, true);
        frmR.lblNota.setText("O seu número de acertos no quiz foi: " + lblNota.getText() + "/5");
        frmR.lblFeedback.setText("Obrigado por nos dizer que sua experiência foi ÓTIMA, isso nos ajuda muito!");
        frmR.setVisible(true);
    }//GEN-LAST:event_btnOtimaActionPerformed

    private void btnRuimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRuimActionPerformed
        dispose();
        frmResumo frmR = new frmResumo(null, true);
        frmR.lblNota.setText("O seu número de acertos no quiz foi: " + lblNota.getText() + "/5");
        frmR.lblFeedback.setText("Obrigado por nos dizer que sua experiência foi RUIM, isso nos ajuda muito!");
        frmR.setVisible(true);
    }//GEN-LAST:event_btnRuimActionPerformed

    private void btnNeutraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNeutraActionPerformed
        dispose();
        frmResumo frmR = new frmResumo(null, true);
        frmR.lblNota.setText("O seu número de acertos no quiz foi: " + lblNota.getText() + "/5");
        frmR.lblFeedback.setText("Obrigado por nos dizer que sua experiência foi NEUTRA, isso nos ajuda muito!");
        frmR.setVisible(true);
    }//GEN-LAST:event_btnNeutraActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                frmAvaliacao dialog = new frmAvaliacao(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnNeutra;
    private javax.swing.JButton btnOtima;
    private javax.swing.JButton btnRuim;
    private javax.swing.JLabel lblAPS;
    private javax.swing.JLabel lblAlienNeutra;
    private javax.swing.JLabel lblAlienOtima;
    private javax.swing.JLabel lblAlienRuim;
    private javax.swing.JLabel lblBackground;
    private javax.swing.JLabel lblFrase1;
    private javax.swing.JLabel lblFrase2;
    public javax.swing.JLabel lblNota;
    private javax.swing.JLabel lblParticipantes;
    // End of variables declaration//GEN-END:variables
}
