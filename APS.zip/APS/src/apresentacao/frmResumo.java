package apresentacao;

import apresentacao.frmPrincipal;  // importando o formulário frmPrincipal

public class frmResumo extends javax.swing.JDialog {

    public frmResumo(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblMensagem = new javax.swing.JLabel();
        lblFrase1 = new javax.swing.JLabel();
        lblNota = new javax.swing.JLabel();
        lblFeedback = new javax.swing.JLabel();
        btnFinalizar = new javax.swing.JButton();
        lblParticipantes = new javax.swing.JLabel();
        lblAPS = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        lblBackground = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Resumo");
        setMaximumSize(new java.awt.Dimension(839, 684));
        setMinimumSize(new java.awt.Dimension(839, 684));
        setPreferredSize(new java.awt.Dimension(839, 684));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lblMensagem.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        lblMensagem.setForeground(new java.awt.Color(255, 255, 255));
        lblMensagem.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMensagem.setText("Aproveite o nosso museu e divirta-se!");
        getContentPane().add(lblMensagem, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 240, 840, -1));

        lblFrase1.setFont(new java.awt.Font("Segoe UI Black", 0, 48)); // NOI18N
        lblFrase1.setForeground(new java.awt.Color(255, 255, 255));
        lblFrase1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblFrase1.setText("OBRIGADO PELA SUA VISITA!");
        getContentPane().add(lblFrase1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 840, -1));

        lblNota.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lblNota.setForeground(new java.awt.Color(255, 255, 255));
        lblNota.setText("NOTA");
        getContentPane().add(lblNota, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 370, -1, -1));

        lblFeedback.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        lblFeedback.setForeground(new java.awt.Color(255, 255, 255));
        lblFeedback.setText("FEEDBACK");
        getContentPane().add(lblFeedback, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 420, -1, -1));

        btnFinalizar.setBackground(new java.awt.Color(243, 243, 243));
        btnFinalizar.setFont(new java.awt.Font("Bookman Old Style", 1, 48)); // NOI18N
        btnFinalizar.setForeground(new java.awt.Color(107, 0, 0));
        btnFinalizar.setText("FINALIZAR");
        btnFinalizar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(61, 23, 23), 5));
        btnFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinalizarActionPerformed(evt);
            }
        });
        getContentPane().add(btnFinalizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 470, 400, 101));

        lblParticipantes.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblParticipantes.setForeground(new java.awt.Color(255, 255, 255));
        lblParticipantes.setText("Cassiano Melo - Gabriel dos Santos - Nicholas Brites - Nicolas Machado");
        getContentPane().add(lblParticipantes, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 620, -1, -1));

        lblAPS.setFont(new java.awt.Font("Dialog", 2, 14)); // NOI18N
        lblAPS.setForeground(new java.awt.Color(255, 255, 255));
        lblAPS.setText("Ciência da Computação - APS 2024");
        getContentPane().add(lblAPS, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 600, -1, -1));

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/logo.png"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 20, 840, 170));

        lblBackground.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/resumo-background.png"))); // NOI18N
        getContentPane().add(lblBackground, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 840, 690));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinalizarActionPerformed
        // como a tela tem uma proposta de apenas entregar na parte visual, e os valores das label's já foram definidos anteriormente
        // o botão apenas fecha a tela frmResumo e gera a tela do frmPrincipal, retornando ao início de tudo
        dispose();
        frmPrincipal frmP = new frmPrincipal(null, true);
        frmP.setVisible(true);
    }//GEN-LAST:event_btnFinalizarActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                frmResumo dialog = new frmResumo(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnFinalizar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblAPS;
    private javax.swing.JLabel lblBackground;
    public javax.swing.JLabel lblFeedback;
    private javax.swing.JLabel lblFrase1;
    private javax.swing.JLabel lblMensagem;
    public javax.swing.JLabel lblNota;
    private javax.swing.JLabel lblParticipantes;
    // End of variables declaration//GEN-END:variables
}
