package modelo;

public class Controle extends AbsPropriedades // herdando atributos e construtores da classe 
{
    
    // construtor herdado da classe AbsPropriedades
    public Controle(String cpf, String nome) {
        super(cpf, nome);
    }

    // método que foi implementado da classe IMetodos na classe AbsPropriedades
    @Override
    public void Executar()
    {
        Estaticos.MENSAGEM = ""; // define MENSAGEM da classe Estaticos como vazia/nula
        AbsPropriedades validacao = new Validacao(cpf, nome); // instanciando um objeto da classe Validacao com os parâmetros de cpf e nome
    }
    
}
